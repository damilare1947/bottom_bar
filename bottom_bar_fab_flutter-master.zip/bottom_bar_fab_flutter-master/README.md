## BottomAppBar Navigation with FAB

Source code for my article:

- [BottomAppBar Navigation with FAB](https://medium.com/coding-with-flutter/flutter-bottomappbar-navigation-with-fab-8b962bb55013)

Tested with [Flutter beta 0.7.3](https://github.com/flutter/flutter/releases/tag/v0.7.3).

## Preview

![](screenshots/BottomAppBar-Navigation-FAB-animation.gif)

### [License: MIT](LICENSE.md)